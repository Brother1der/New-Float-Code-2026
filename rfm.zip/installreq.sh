#!/bin/bash

echo "Creating venv"
python3 -m venv rfm_env

echo "Activating venv"
source rfm_env/bin/activate

echo "Installing Python 3.11.14"
tar -xf Python-3.11.14.tar.xz

echo "Installing Python dependencies"
pip install -r requirements.txt

echo "Setting cd"
cd rfm_env

echo "Running script"
python radio_rfm9x.py
